# ♬ Mainstage EDM Sub-Genre Benchmark
An extended classification benchmark for mainstream dance music in the style of house.

## Checking existing annotations
We prepared a simple UI to see existing annotations (.csv). Run ```utils.py``` to view annotations of audio files in a folder. Before you run, please make sure you have modified ```anno_path``` and ```audio_dir``` in the .py file to your corresponding paths.
